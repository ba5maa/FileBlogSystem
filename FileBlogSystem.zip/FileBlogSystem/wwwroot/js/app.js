// Remove all require(...) lines

// Main application controller
window.BlogApp = {
  currentRoute: BlogConfig.ROUTES.HOME,
  currentParam: null,

  async init() {
    BlogAuth.loadAuthData()
    this.setupRouting()
    await this.render()
  },

  setupRouting() {
    window.addEventListener("popstate", (e) => {
      if (e.state) {
        this.currentRoute = e.state.route
        this.currentParam = e.state.param
        this.render()
      }
    })
  },

  navigate(route, param = null) {
    this.currentRoute = route
    this.currentParam = param
    const url = param ? `#${route}/${param}` : `#${route}`
    history.pushState({ route, param }, "", url)
    this.render()
  },

  async render() {
    Navigation.render()
    Navigation.updateActiveRoute(this.currentRoute)

    switch (this.currentRoute) {
      case BlogConfig.ROUTES.HOME:
        await HomePage.render()
        break
      case BlogConfig.ROUTES.CREATE:
        if (!BlogAuth.isAuthenticated()) {
          Modals.showAuthModal("login")
          return
        }
        await CreatePostPage.render(this.currentParam)
        break
      case BlogConfig.ROUTES.BLOG_DETAIL:
        if (this.currentParam) {
          await BlogDetailPage.render(this.currentParam)
        } else {
          this.navigate(BlogConfig.ROUTES.HOME)
        }
        break
      case BlogConfig.ROUTES.DRAFTS:
        await DraftsPage.render()
        break
      case BlogConfig.ROUTES.ADMIN:
        await AdminPage.render()
        break
      case BlogConfig.ROUTES.LOGIN:
        Modals.showAuthModal("login")
        break
      case BlogConfig.ROUTES.SIGNUP:
        Modals.showAuthModal("signup")
        break
      default:
        await HomePage.render()
    }
  },
}

document.addEventListener("DOMContentLoaded", () => {
  BlogApp.init()
})
