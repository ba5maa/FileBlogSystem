// Application configuration
window.BlogConfig = {
  API_BASE_URL: "http://localhost:5211",
  ROUTES: {
    HOME: "home",
    CREATE: "create",
    BLOG_DETAIL: "blog-detail",
    DRAFTS: "drafts",
    ADMIN: "admin",
    LOGIN: "login",
    SIGNUP: "signup",
  },
  STORAGE_KEYS: {
    USER: "user",
    TOKEN: "token",
    TOKEN_EXPIRES: "tokenExpires",
  },
}
