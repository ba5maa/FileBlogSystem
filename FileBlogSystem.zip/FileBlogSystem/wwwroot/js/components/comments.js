// Comments component
window.Comments = {
  async loadForPost(postSlug) {
    const commentsSection = document.getElementById("comments-section")

    if (!window.BlogAuth.isAuthenticated()) {
      commentsSection.innerHTML = `
        <div style="padding: 2rem; text-align: center; background: #f8f9fa; margin-top: 2rem; border-radius: 12px;">
          <p>Please <a href="#" onclick="window.BlogApp.navigate('${window.BlogConfig.ROUTES.LOGIN}')">login</a> to view and post comments.</p>
        </div>
      `
      return
    }

    commentsSection.innerHTML = `
      <div style="padding: 2rem; background: #f8f9fa; margin-top: 2rem; border-radius: 12px;">
        <h3 style="margin-bottom: 1.5rem; color: #333;">
          <i class="fas fa-comments"></i> Comments
        </h3>
        
        <div class="comment-form" style="margin-bottom: 2rem;">
          <textarea id="comment-input" placeholder="Write a comment..." style="width: 100%; min-height: 100px; padding: 1rem; border: 2px solid #e1e5e9; border-radius: 8px; resize: vertical; font-family: inherit;"></textarea>
          <button id="submit-comment" class="btn btn-primary" style="margin-top: 1rem;">
            <i class="fas fa-paper-plane"></i> Post Comment
          </button>
        </div>
        
        <div id="comments-list">
          <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading comments...</p>
          </div>
        </div>
      </div>
    `

    this.setupEventListeners(postSlug)
    await this.loadComments(postSlug)
  },

  setupEventListeners(postSlug) {
    const submitBtn = document.getElementById("submit-comment")
    const commentInput = document.getElementById("comment-input")

    submitBtn.addEventListener("click", async () => {
      const content = commentInput.value.trim()
      if (!content) return

      await this.addComment(postSlug, content)
      commentInput.value = ""
    })

    commentInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
        submitBtn.click()
      }
    })
  },

  async loadComments(postSlug) {
    const commentsList = document.getElementById("comments-list")

    try {
      const response = await window.BlogAPI.fetchAuthenticated(
        `${window.BlogConfig.API_BASE_URL}/api/post/${postSlug}/comments`,
      )
      const comments = await response.json()

      if (comments.length === 0) {
        commentsList.innerHTML = `
          <p style="text-align: center; color: #666; font-style: italic;">
            No comments yet. Be the first to comment!
          </p>
        `
        return
      }

      commentsList.innerHTML = comments
        .map(
          (comment) => `
        <div class="comment-item" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; border-left: 3px solid #667eea;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <div style="font-weight: 600; color: #333;">
              <i class="fas fa-user" style="margin-right: 0.5rem; color: #667eea;"></i>
              @${comment.username}
            </div>
            <div style="color: #666; font-size: 0.9rem;">
              ${window.BlogUtils.formatDate(comment.createdAt)}
            </div>
          </div>
          <p style="margin: 0; color: #555; line-height: 1.5;">${comment.content}</p>
        </div>
      `,
        )
        .join("")
    } catch (error) {
      console.error("Error loading comments:", error)
      commentsList.innerHTML = `
        <p style="text-align: center; color: #dc3545;">
          Error loading comments. Please try again later.
        </p>
      `
    }
  },

  async addComment(postSlug, content) {
    try {
      const response = await window.BlogAPI.fetchAuthenticated(
        `${window.BlogConfig.API_BASE_URL}/api/post/${postSlug}/comment`,
        {
          method: "POST",
          body: JSON.stringify({
            content: content,
            username: window.BlogAuth.user.username,
            createdAt: new Date().toISOString(),
          }),
        },
      )

      if (response.ok) {
        await this.loadComments(postSlug)
        window.BlogUtils.showMessage("Comment added successfully!", "success")
      } else {
        throw new Error("Failed to add comment")
      }
    } catch (error) {
      console.error("Error adding comment:", error)
      window.BlogUtils.showMessage("Error adding comment. Please try again.", "error")
    }
  },
}
