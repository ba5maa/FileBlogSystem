// Navigation component
window.Navigation = {
  render() {
    const mainNav = document.getElementById("main-nav")
    const BlogAuth = window.BlogAuth // Declare BlogAuth
    const BlogConfig = window.BlogConfig // Declare BlogConfig
    const BlogApp = window.BlogApp // Declare BlogApp

    if (BlogAuth.isAuthenticated()) {
      mainNav.innerHTML = `
        <div class="nav-links">
          <button class="nav-btn" data-route="${BlogConfig.ROUTES.HOME}">
            <i class="fas fa-home"></i> Home
          </button>
          <button class="nav-btn" data-route="${BlogConfig.ROUTES.CREATE}">
            <i class="fas fa-plus"></i> Create
          </button>
          <button class="nav-btn" data-route="${BlogConfig.ROUTES.DRAFTS}">
            <i class="fas fa-edit"></i> My Posts
          </button>
          ${
            BlogAuth.user.roles && BlogAuth.user.roles.includes("Admin")
              ? `
            <button class="nav-btn" data-route="${BlogConfig.ROUTES.ADMIN}">
              <i class="fas fa-shield-alt"></i> Admin
            </button>
          `
              : ""
          }
        </div>
        <div class="nav-user">
          <div class="dropdown">
            <button class="dropdown-toggle" id="profile-dropdown">
              <img src="${BlogAuth.user.profilePictureUrl || `${BlogConfig.API_BASE_URL}/content/static/avatar.jpg`}" class="avatar-img" alt="Avatar" />
              <span>${BlogAuth.user.username}</span>
              <i class="fas fa-chevron-down"></i>
            </button>
            <div class="dropdown-menu" id="profile-menu">
              <a href="#" class="dropdown-item" id="edit-profile-btn">
                <i class="fas fa-user-edit"></i> Edit Profile
              </a>
              <a href="#" class="dropdown-item" id="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
              </a>
            </div>
          </div>
        </div>
      `

      this.setupAuthenticatedListeners()
    } else {
      mainNav.innerHTML = `
        <button class="nav-btn" data-route="${BlogConfig.ROUTES.LOGIN}">
          <i class="fas fa-sign-in-alt"></i> Login
        </button>
        <button class="nav-btn" data-route="${BlogConfig.ROUTES.SIGNUP}">
          <i class="fas fa-user-plus"></i> Sign Up
        </button>
      `
    }

    this.setupCommonListeners()
  },

  setupCommonListeners() {
    document.querySelectorAll(".nav-btn[data-route]").forEach((btn) => {
      btn.addEventListener("click", () => {
        window.BlogApp.navigate(btn.dataset.route) // Use window.BlogApp
      })
    })
  },

  setupAuthenticatedListeners() {
    const profileDropdown = document.getElementById("profile-dropdown")
    const profileMenu = document.getElementById("profile-menu")
    const logoutBtn = document.getElementById("logout-btn")

    if (profileDropdown) {
      profileDropdown.addEventListener("click", (e) => {
        e.stopPropagation()
        profileMenu.classList.toggle("show")
      })
    }

    document.addEventListener("click", () => {
      if (profileMenu) {
        profileMenu.classList.remove("show")
      }
    })

    if (logoutBtn) {
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault()
        window.BlogAuth.clearAuthData() // Use window.BlogAuth
        window.BlogApp.navigate(window.BlogConfig.ROUTES.HOME) // Use window.BlogApp and window.BlogConfig
      })
    }
  },

  updateActiveRoute(route) {
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.remove("active")
    })

    const activeBtn = document.querySelector(`[data-route="${route}"]`)
    if (activeBtn) {
      activeBtn.classList.add("active")
    }
  },
}
