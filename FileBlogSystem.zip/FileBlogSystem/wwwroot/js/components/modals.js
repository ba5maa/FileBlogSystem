// Modal components
window.Modals = {
  showAuthModal(type = "login") {
    const modalHtml = `
      <div class="modal-overlay" id="auth-modal">
        <div class="auth-card">
          <div class="auth-header">
            <h2 id="auth-title">${type === "login" ? "Welcome Back" : "Create Account"}</h2>
            <p id="auth-subtitle">${type === "login" ? "Sign in to your account" : "Join our community"}</p>
          </div>
          
          <form id="auth-form" class="auth-form">
            <div class="form-group">
              <label for="username"><i class="fas fa-user"></i> Username</label>
              <input type="text" id="username" required>
            </div>
            
            <div class="form-group">
              <label for="password"><i class="fas fa-lock"></i> Password</label>
              <input type="password" id="password" required>
            </div>
            
            <div id="signup-fields" style="display: ${type === "signup" ? "block" : "none"};">
              <div class="form-group">
                <label for="confirm-password"><i class="fas fa-lock"></i> Confirm Password</label>
                <input type="password" id="confirm-password"> 
              </div>
              <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email</label>
                <input type="email" id="email">
              </div>
            </div>
            
            <button type="submit" class="auth-submit-btn" id="auth-submit">
              <i class="fas fa-sign-in-alt"></i>
              <span id="submit-text">${type === "login" ? "Sign In" : "Create Account"}</span>
            </button>
            
            <div class="auth-switch">
              <p id="auth-switch-text">
                ${type === "login" ? "Don't have an account?" : "Already have an account?"}
                <a href="#" id="auth-switch-link">${type === "login" ? "Sign Up" : "Sign In"}</a>
              </p>
            </div>
            
            <div id="auth-message" class="message" style="display: none;"></div>
          </form>
        </div>
      </div>
    `

    document.body.insertAdjacentHTML("beforeend", modalHtml)
    this.setupAuthModalListeners(type)
  },

  setupAuthModalListeners(initialType) {
    const modal = document.getElementById("auth-modal")
    const form = document.getElementById("auth-form")
    const messageElement = document.getElementById("auth-message")
    let currentType = initialType

    // Close modal when clicking outside
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.remove()
      }
    })

    // Switch between login and signup
    document.getElementById("auth-switch-link").addEventListener("click", (e) => {
      e.preventDefault()
      currentType = currentType === "login" ? "signup" : "login"

      const signupFields = document.getElementById("signup-fields")
      const authTitle = document.getElementById("auth-title")
      const authSubtitle = document.getElementById("auth-subtitle")
      const submitText = document.getElementById("submit-text")
      const authSwitchText = document.getElementById("auth-switch-text")

      if (currentType === "signup") {
        signupFields.style.display = "block"
        authTitle.textContent = "Create Account"
        authSubtitle.textContent = "Join our community"
        submitText.textContent = "Create Account"
        authSwitchText.innerHTML = 'Already have an account? <a href="#" id="auth-switch-link">Sign In</a>'
      } else {
        signupFields.style.display = "none"
        authTitle.textContent = "Welcome Back"
        authSubtitle.textContent = "Sign in to your account"
        submitText.textContent = "Sign In"
        authSwitchText.innerHTML = 'Don\'t have an account? <a href="#" id="auth-switch-link">Sign Up</a>'
      }

      // Re-attach event listener to new switch link
      document.getElementById("auth-switch-link").addEventListener("click", (e) => {
        e.preventDefault()
        currentType = currentType === "login" ? "signup" : "login"

        const signupFields = document.getElementById("signup-fields")
        const authTitle = document.getElementById("auth-title")
        const authSubtitle = document.getElementById("auth-subtitle")
        const submitText = document.getElementById("submit-text")
        const authSwitchText = document.getElementById("auth-switch-text")

        if (currentType === "signup") {
          signupFields.style.display = "block"
          authTitle.textContent = "Create Account"
          authSubtitle.textContent = "Join our community"
          submitText.textContent = "Create Account"
          authSwitchText.innerHTML = 'Already have an account? <a href="#" id="auth-switch-link">Sign In</a>'
        } else {
          signupFields.style.display = "none"
          authTitle.textContent = "Welcome Back"
          authSubtitle.textContent = "Sign in to your account"
          submitText.textContent = "Sign In"
          authSwitchText.innerHTML = 'Don\'t have an account? <a href="#" id="auth-switch-link">Sign Up</a>'
        }

        messageElement.style.display = "none"
      })
      messageElement.style.display = "none"
    })

    // Form submission
    form.addEventListener("submit", async (e) => {
      e.preventDefault()

      const username = document.getElementById("username").value.trim()
      const password = document.getElementById("password").value

      const BlogUtils = window.BlogUtils // Declare BlogUtils
      const BlogAuth = window.BlogAuth // Declare BlogAuth
      const BlogApp = window.BlogApp // Declare BlogApp

      if (currentType === "signup") {
        const confirmPassword = document.getElementById("confirm-password").value
        const email = document.getElementById("email").value.trim()

        if (password !== confirmPassword) {
          BlogUtils.showMessage("Passwords do not match", "error", messageElement)
          return
        }

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          BlogUtils.showMessage("Please enter a valid email address", "error", messageElement)
          return
        }

        try {
          await BlogAuth.signup({ username, password, email, roles: ["Author"] })
          BlogUtils.showMessage("Account created successfully!", "success", messageElement)
          modal.remove()
          BlogApp.render()
        } catch (error) {
          BlogUtils.showMessage(error.message, "error", messageElement)
        }
      } else {
        try {
          await BlogAuth.login({ username, password })
          BlogUtils.showMessage("Login successful!", "success", messageElement)
          modal.remove()
          BlogApp.render()
        } catch (error) {
          BlogUtils.showMessage(error.message, "error", messageElement)
        }
      }
    })
  },
}
