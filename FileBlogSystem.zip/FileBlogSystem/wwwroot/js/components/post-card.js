// Post card component
window.PostCard = {
  create(post) {
    const card = document.createElement("div")
    card.className = "post-card"
    card.addEventListener("click", () => {
      window.BlogApp.navigate(window.BlogConfig.ROUTES.BLOG_DETAIL, post.slug)
    })

    card.innerHTML = `
      ${
        post.imageUrl
          ? `
        <img src="${window.BlogConfig.API_BASE_URL}${post.imageUrl}" alt="${post.title}" class="post-card-image">
      `
          : ""
      }
      <div class="post-card-content">
        <h3 class="post-card-title">${post.title}</h3>
        <p class="post-card-excerpt">${this.getExcerpt(post.content)}</p>
        <div class="post-card-meta">
          <div class="post-card-author">
            <i class="fas fa-user"></i>
            <span>@${post.authorUsername}</span>
          </div>
          <div class="post-card-date">
            ${window.BlogUtils.formatDate(post.publishedDate || post.creationDate)}
          </div>
        </div>
      </div>
    `

    return card
  },

  getExcerpt(content, maxLength = 150) {
    if (!content) return ""

    // Remove markdown formatting for excerpt
    const plainText = content
      .replace(/[#*_`]/g, "")
      .replace(/\[([^\]]*)\]$$[^$$]*\)/g, "$1")
      .replace(/!\[([^\]]*)\]$$[^$$]*\)/g, "")
      .trim()

    return plainText.length > maxLength ? plainText.substring(0, maxLength) + "..." : plainText
  },
}

// Declare variables before using them
window.BlogApp = window.BlogApp || {}
window.BlogConfig = window.BlogConfig || {}
window.BlogUtils = window.BlogUtils || {}
