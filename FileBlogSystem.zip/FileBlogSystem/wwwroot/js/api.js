// API communication layer
window.BlogAPI = {
  async fetchAuthenticated(url, options = {}) {
    if (!window.BlogAuth.isAuthenticated()) {
      console.warn("Attempted authenticated fetch without valid token.")
      window.BlogAuth.clearAuthData()
      window.BlogApp.navigate(window.BlogConfig.ROUTES.LOGIN)
      throw new Error("Authentication required.")
    }

    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${window.BlogAuth.token}`,
      ...(options.headers || {}),
    }

    try {
      const response = await fetch(url, { ...options, headers })

      if (response.status === 401 || response.status === 403) {
        console.error(`Authorization error: ${response.status} for ${url}`)
        window.BlogUtils.showMessage("Your session has expired. Please log in again.", "error")
        window.BlogAuth.clearAuthData()
        window.BlogApp.navigate(window.BlogConfig.ROUTES.LOGIN)
        throw new Error(`Authorization error: ${response.status}`)
      }
      return response
    } catch (error) {
      console.error(`Network or fetch error for ${url}:`, error)
      throw error
    }
  },

  async getPosts(filters = {}) {
    const queryParams = new URLSearchParams()
    Object.keys(filters).forEach((key) => {
      if (filters[key]) queryParams.append(key, filters[key])
    })

    const url = `${window.BlogConfig.API_BASE_URL}/api/posts?${queryParams.toString()}`
    const response = await this.fetchAuthenticated(url)

    if (!response.ok) {
      throw new Error("Failed to fetch posts")
    }

    return await response.json()
  },

  async getPost(slug) {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/post/${slug}`)

    if (!response.ok) {
      throw new Error("Failed to fetch post")
    }

    return await response.json()
  },

  async createPost(postData) {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/post`, {
      method: "POST",
      body: JSON.stringify(postData),
    })

    if (!response.ok) {
      const data = await response.json()
      throw new Error(data.message || "Failed to create post")
    }

    return await response.json()
  },

  async updatePost(slug, postData) {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/update-post/${slug}`, {
      method: "PUT",
      body: JSON.stringify(postData),
    })

    if (!response.ok) {
      const data = await response.json()
      throw new Error(data.message || "Failed to update post")
    }

    return await response.json()
  },

  async deletePost(slug) {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/delete-post/${slug}`, {
      method: "DELETE",
    })

    if (response.status !== 204) {
      throw new Error("Failed to delete post")
    }

    return true
  },

  async getCategories() {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/categories`)
    return response.ok ? await response.json() : []
  },

  async getTags() {
    const response = await this.fetchAuthenticated(`${window.BlogConfig.API_BASE_URL}/api/tags`)
    return response.ok ? await response.json() : []
  },
}

// Declare or import the required variables here
window.BlogAuth = {
  isAuthenticated: () => true,
  clearAuthData: () => {},
  token: "dummyToken",
}

window.BlogApp = {
  navigate: (route) => {},
}

window.BlogConfig = {
  API_BASE_URL: "https://example.com",
  ROUTES: {
    LOGIN: "/login",
  },
}

window.BlogUtils = {
  showMessage: (message, type) => {},
}
