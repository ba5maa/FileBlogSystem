// Authentication management
const BlogConfig = {
  STORAGE_KEYS: {
    USER: "blog_user",
    TOKEN: "blog_token",
    TOKEN_EXPIRES: "blog_token_expires",
  },
  API_BASE_URL: "https://api.example.com",
}

window.BlogAuth = {
  user: null,
  token: null,
  tokenExpires: null,

  loadAuthData() {
    try {
      this.user = JSON.parse(localStorage.getItem(BlogConfig.STORAGE_KEYS.USER)) || null
      this.token = localStorage.getItem(BlogConfig.STORAGE_KEYS.TOKEN) || null
      this.tokenExpires = localStorage.getItem(BlogConfig.STORAGE_KEYS.TOKEN_EXPIRES)
        ? new Date(localStorage.getItem(BlogConfig.STORAGE_KEYS.TOKEN_EXPIRES))
        : null

      if (this.tokenExpires && this.tokenExpires <= new Date()) {
        console.warn("Token expired. Clearing authentication data.")
        this.clearAuthData()
      }
    } catch (e) {
      console.error("Failed to load auth data from localStorage:", e)
      this.clearAuthData()
    }
  },

  saveAuthData() {
    localStorage.setItem(BlogConfig.STORAGE_KEYS.USER, JSON.stringify(this.user))
    localStorage.setItem(BlogConfig.STORAGE_KEYS.TOKEN, this.token)
    localStorage.setItem(
      BlogConfig.STORAGE_KEYS.TOKEN_EXPIRES,
      this.tokenExpires ? this.tokenExpires.toISOString() : "",
    )
  },

  clearAuthData() {
    this.user = null
    this.token = null
    this.tokenExpires = null
    localStorage.removeItem(BlogConfig.STORAGE_KEYS.USER)
    localStorage.removeItem(BlogConfig.STORAGE_KEYS.TOKEN)
    localStorage.removeItem(BlogConfig.STORAGE_KEYS.TOKEN_EXPIRES)
  },

  isAuthenticated() {
    return !!this.user && !!this.token && this.tokenExpires && this.tokenExpires > new Date()
  },

  async login(credentials) {
    const response = await fetch(`${BlogConfig.API_BASE_URL}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || "Login failed")
    }

    // Get full user data
    try {
      const userResponse = await fetch(`${BlogConfig.API_BASE_URL}/api/user/${data.user.username}`, {
        headers: { Authorization: `Bearer ${data.token}` },
      })

      if (userResponse.ok) {
        const fullUserData = await userResponse.json()
        this.user = {
          username: data.user.username,
          roles: data.user.roles || ["Author"],
          email: fullUserData.email,
          profilePictureUrl: fullUserData.profilePictureUrl,
        }
      } else {
        this.user = { username: data.user.username, roles: data.user.roles || ["Author"] }
      }
    } catch (error) {
      this.user = { username: data.user.username, roles: data.user.roles || ["Author"] }
    }

    this.token = data.token
    this.tokenExpires = new Date(data.expires)
    this.saveAuthData()

    return this.user
  },

  async signup(userData) {
    const response = await fetch(`${BlogConfig.API_BASE_URL}/api/user`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userData),
    })

    if (!response.ok) {
      const data = await response.json()
      throw new Error(data.message || "Signup failed")
    }

    // Auto-login after signup
    return await this.login({
      username: userData.username,
      password: userData.password,
    })
  },
}
