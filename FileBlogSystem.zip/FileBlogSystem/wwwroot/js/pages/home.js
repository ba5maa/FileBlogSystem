// Home page functionality
window.HomePage = {
  async render() {
    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="home-page">
        <div class="hero-section">
          <h1 class="hero-title">
            <i class="fas fa-blog"></i>
            Welcome to Your Blog
          </h1>
          <p class="hero-subtitle">
            Share your thoughts, ideas, and stories with the world
          </p>
          <div class="hero-cta">
            <button class="btn btn-primary" id="create-blog-btn">
              <i class="fas fa-plus"></i>
              Create New Blog
            </button>
            <button class="btn btn-outline" id="browse-blogs-btn">
              <i class="fas fa-book-open"></i>
              Browse Blogs
            </button>
          </div>
        </div>
        
        <div class="posts-section">
          <h2 style="color: white; text-align: center; margin-bottom: 2rem;">
            <i class="fas fa-fire"></i> Latest Posts
          </h2>
          <div id="posts-grid" class="posts-grid">
            <div class="loading-spinner">
              <i class="fas fa-spinner fa-spin"></i>
              <p>Loading posts...</p>
            </div>
          </div>
        </div>
      </div>
    `

    this.setupEventListeners()
    await this.loadPosts()
  },

  setupEventListeners() {
    document.getElementById("create-blog-btn").addEventListener("click", () => {
      if (window.BlogAuth.isAuthenticated()) {
        window.BlogApp.navigate(window.BlogConfig.ROUTES.CREATE)
      } else {
        window.BlogApp.navigate(window.BlogConfig.ROUTES.LOGIN)
      }
    })

    document.getElementById("browse-blogs-btn").addEventListener("click", () => {
      document.getElementById("posts-grid").scrollIntoView({ behavior: "smooth" })
    })
  },

  async loadPosts() {
    const postsGrid = document.getElementById("posts-grid")

    try {
      const posts = await window.BlogAPI.getPosts({ isDraft: "false" })

      if (posts.length === 0) {
        postsGrid.innerHTML = `
          <div style="grid-column: 1 / -1; text-align: center; color: white; padding: 2rem;">
            <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
            <h3>No posts yet</h3>
            <p>Be the first to create a blog post!</p>
          </div>
        `
        return
      }

      postsGrid.innerHTML = ""

      posts.slice(0, 6).forEach((post) => {
        const postCard = window.PostCard.create(post)
        postsGrid.appendChild(postCard)
      })
    } catch (error) {
      console.error("Error loading posts:", error)
      postsGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; color: #dc3545; padding: 2rem;">
          <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 1rem;"></i>
          <h3>Error loading posts</h3>
          <p>${error.message}</p>
        </div>
      `
    }
  },
}

// Assuming these variables are declared elsewhere in your codebase
window.BlogAuth = {
  isAuthenticated: () => true, // Example implementation
}

window.BlogApp = {
  navigate: (route) => console.log(`Navigating to ${route}`), // Example implementation
}

window.BlogConfig = {
  ROUTES: {
    CREATE: "/create",
    LOGIN: "/login",
  },
}

window.BlogAPI = {
  getPosts: async (params) => {
    // Example implementation
    return [
      { title: "Post 1", content: "Content of post 1" },
      { title: "Post 2", content: "Content of post 2" },
    ]
  },
}

window.PostCard = {
  create: (post) => {
    const card = document.createElement("div")
    card.className = "post-card"
    card.innerHTML = `
      <h3>${post.title}</h3>
      <p>${post.content}</p>
    `
    return card
  },
}
