// Admin page functionality (simplified version)
window.AdminPage = {
  async render() {
    // Declare variables before using them
    const BlogAuth = window.BlogAuth // Assuming BlogAuth is a global object
    const BlogUtils = window.BlogUtils // Assuming BlogUtils is a global object
    const BlogApp = window.BlogApp // Assuming BlogApp is a global object
    const BlogConfig = window.BlogConfig // Assuming BlogConfig is a global object

    if (!BlogAuth.isAuthenticated() || !BlogAuth.user.roles.includes("Admin")) {
      BlogUtils.showMessage("You must be an admin to access this page.", "error")
      BlogApp.navigate(BlogConfig.ROUTES.HOME)
      return
    }

    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="admin-page">
        <div class="page-header">
          <h2><i class="fas fa-shield-alt"></i> Admin Panel</h2>
          <p>Manage your blog system</p>
        </div>
        
        <div class="admin-sections">
          <div class="admin-section">
            <h3><i class="fas fa-users"></i> User Management</h3>
            <p>Manage users, roles, and permissions</p>
            <button class="btn btn-primary">
              <i class="fas fa-cog"></i> Manage Users
            </button>
          </div>
          
          <div class="admin-section">
            <h3><i class="fas fa-folder"></i> Categories</h3>
            <p>Create and manage blog categories</p>
            <button class="btn btn-primary">
              <i class="fas fa-plus"></i> Add Category
            </button>
          </div>
          
          <div class="admin-section">
            <h3><i class="fas fa-tags"></i> Tags</h3>
            <p>Create and manage blog tags</p>
            <button class="btn btn-primary">
              <i class="fas fa-plus"></i> Add Tag
            </button>
          </div>
        </div>
      </div>
    `
  },
}
