// Profile page functionality
window.ProfilePage = {
  async render() {
    const BlogAuth = window.BlogAuth // Declare BlogAuth variable
    const BlogUtils = window.BlogUtils // Declare BlogUtils variable
    const BlogApp = window.BlogApp // Declare BlogApp variable
    const BlogConfig = window.BlogConfig // Declare BlogConfig variable

    if (!BlogAuth.isAuthenticated()) {
      BlogUtils.showMessage("You must be logged in to view your profile.", "error")
      BlogApp.navigate(BlogConfig.ROUTES.LOGIN)
      return
    }

    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="profile-page">
        <div class="page-header">
          <h2><i class="fas fa-user"></i> My Profile</h2>
          <p>Manage your account settings</p>
        </div>
        
        <div class="profile-content">
          <div class="profile-info">
            <img src="${BlogAuth.user.profilePictureUrl || `${BlogConfig.API_BASE_URL}/content/static/avatar.jpg`}" 
                 alt="Profile Picture" class="profile-picture">
            <h3>@${BlogAuth.user.username}</h3>
            <p>${BlogAuth.user.email}</p>
            <div class="user-roles">
              ${BlogAuth.user.roles.map((role) => `<span class="role-badge">${role}</span>`).join("")}
            </div>
          </div>
          
          <div class="profile-actions">
            <button class="btn btn-primary" id="edit-profile-btn">
              <i class="fas fa-edit"></i> Edit Profile
            </button>
            <button class="btn btn-outline" id="change-password-btn">
              <i class="fas fa-key"></i> Change Password
            </button>
          </div>
        </div>
      </div>
    `

    this.setupEventListeners()
  },

  setupEventListeners() {
    document.getElementById("edit-profile-btn").addEventListener("click", () => {
      // Show edit profile modal
      window.BlogUtils.showMessage("Edit profile functionality coming soon!", "info")
    })

    document.getElementById("change-password-btn").addEventListener("click", () => {
      // Show change password modal
      window.BlogUtils.showMessage("Change password functionality coming soon!", "info")
    })
  },
}
