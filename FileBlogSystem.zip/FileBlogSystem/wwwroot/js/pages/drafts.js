// Drafts page functionality
window.DraftsPage = {
  async render() {
    const BlogAuth = window.BlogAuth // Declare BlogAuth
    const BlogUtils = window.BlogUtils // Declare BlogUtils
    const BlogApp = window.BlogApp // Declare BlogApp
    const BlogConfig = window.BlogConfig // Declare BlogConfig
    const BlogAPI = window.BlogAPI // Declare BlogAPI

    if (!BlogAuth.isAuthenticated()) {
      BlogUtils.showMessage("You must be logged in to view your drafts.", "error")
      BlogApp.navigate(BlogConfig.ROUTES.LOGIN)
      return
    }

    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="drafts-page">
        <div class="page-header">
          <h2><i class="fas fa-edit"></i> My Posts & Drafts</h2>
          <p>Manage your published posts and drafts</p>
        </div>
        
        <div id="drafts-container" class="drafts-container">
          <div class="loading-posts">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Loading your posts...</p>
          </div>
        </div>
      </div>
    `

    await this.loadUserPosts()
  },

  async loadUserPosts() {
    const container = document.getElementById("drafts-container")
    const BlogAuth = window.BlogAuth // Declare BlogAuth
    const BlogUtils = window.BlogUtils // Declare BlogUtils
    const BlogApp = window.BlogApp // Declare BlogApp
    const BlogConfig = window.BlogConfig // Declare BlogConfig
    const BlogAPI = window.BlogAPI // Declare BlogAPI

    try {
      const [drafts, published] = await Promise.all([
        BlogAPI.getPosts({ authorUsername: BlogAuth.user.username, isDraft: "true" }),
        BlogAPI.getPosts({ authorUsername: BlogAuth.user.username, isDraft: "false" }),
      ])

      const allPosts = [...drafts, ...published]

      if (allPosts.length === 0) {
        container.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-file-alt"></i>
            <h3>No posts yet</h3>
            <p>Start writing your first blog post!</p>
            <button class="btn btn-primary" onclick="BlogApp.navigate('${BlogConfig.ROUTES.CREATE}')">
              <i class="fas fa-plus"></i> Create New Post
            </button>
          </div>
        `
        return
      }

      container.innerHTML = ""

      allPosts.forEach((post) => {
        const postCard = this.createPostCard(post)
        container.appendChild(postCard)
      })
    } catch (error) {
      console.error("Error loading user posts:", error)
      container.innerHTML = `
        <div class="error-state">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Error loading your posts: ${error.message}</p>
        </div>
      `
    }
  },

  createPostCard(post) {
    const card = document.createElement("div")
    card.className = "draft-card"
    const BlogUtils = window.BlogUtils // Declare BlogUtils
    const BlogConfig = window.BlogConfig // Declare BlogConfig

    card.innerHTML = `
      <div class="draft-header">
        <div class="author-details">
          <span class="post-author">@${post.authorUsername}</span>
          <span class="draft-date">Last modified: ${BlogUtils.formatDate(post.modificationDate || post.creationDate)}</span>
        </div>
        <div class="post-status">
          ${
            post.isDraft
              ? '<span class="draft-badge"><i class="fas fa-edit"></i> Draft</span>'
              : '<span class="published-badge"><i class="fas fa-check-circle"></i> Published</span>'
          }
        </div>
      </div>
      
      <div class="draft-content">
        <h3>${post.title}</h3>
        <p>${post.content.substring(0, 150)}${post.content.length > 150 ? "..." : ""}</p>
        ${post.imageUrl ? `<img src="${BlogConfig.API_BASE_URL}${post.imageUrl}" alt="${post.title}" class="post-image-preview" style="max-width: 150px; margin-top: 10px; border-radius: 8px;">` : ""}
      </div>
      
      <div class="draft-actions">
        <button class="btn btn-primary edit-btn" data-slug="${post.slug}">
          <i class="fas fa-edit"></i> Edit
        </button>
        ${
          post.isDraft
            ? `
          <button class="btn btn-success publish-btn" data-slug="${post.slug}">
            <i class="fas fa-paper-plane"></i> Publish
          </button>
        `
            : `
          <button class="btn btn-outline view-btn" data-slug="${post.slug}">
            <i class="fas fa-eye"></i> View
          </button>
        `
        }
        <button class="btn btn-danger delete-btn" data-slug="${post.slug}">
          <i class="fas fa-trash"></i> Delete
        </button>
      </div>
    `

    this.setupCardListeners(card)
    return card
  },

  setupCardListeners(card) {
    const editBtn = card.querySelector(".edit-btn")
    const publishBtn = card.querySelector(".publish-btn")
    const viewBtn = card.querySelector(".view-btn")
    const deleteBtn = card.querySelector(".delete-btn")
    const BlogApp = window.BlogApp // Declare BlogApp
    const BlogConfig = window.BlogConfig // Declare BlogConfig

    if (editBtn) {
      editBtn.addEventListener("click", () => {
        BlogApp.navigate(BlogConfig.ROUTES.CREATE, editBtn.dataset.slug)
      })
    }

    if (publishBtn) {
      publishBtn.addEventListener("click", async () => {
        const BlogUtils = window.BlogUtils // Declare BlogUtils
        if (confirm("Are you sure you want to publish this draft?")) {
          await this.publishDraft(publishBtn.dataset.slug)
        }
      })
    }

    if (viewBtn) {
      viewBtn.addEventListener("click", () => {
        const BlogConfig = window.BlogConfig // Declare BlogConfig
        const BlogApp = window.BlogApp // Declare BlogApp
        BlogApp.navigate(BlogConfig.ROUTES.BLOG_DETAIL, viewBtn.dataset.slug)
      })
    }

    if (deleteBtn) {
      deleteBtn.addEventListener("click", async () => {
        const BlogUtils = window.BlogUtils // Declare BlogUtils
        if (confirm("Are you sure you want to delete this post? This action cannot be undone.")) {
          await this.deletePost(deleteBtn.dataset.slug)
        }
      })
    }
  },

  async publishDraft(slug) {
    const BlogAPI = window.BlogAPI // Declare BlogAPI
    const BlogUtils = window.BlogUtils // Declare BlogUtils
    const BlogConfig = window.BlogConfig // Declare BlogConfig

    try {
      const post = await BlogAPI.getPost(slug)
      post.isDraft = false
      post.publishedDate = new Date().toISOString()

      await BlogAPI.updatePost(slug, post)
      BlogUtils.showMessage("Draft published successfully!", "success")
      await this.loadUserPosts()
    } catch (error) {
      console.error("Error publishing draft:", error)
      BlogUtils.showMessage("Error publishing draft: " + error.message, "error")
    }
  },

  async deletePost(slug) {
    const BlogAPI = window.BlogAPI // Declare BlogAPI
    const BlogUtils = window.BlogUtils // Declare BlogUtils

    try {
      await BlogAPI.deletePost(slug)
      BlogUtils.showMessage("Post deleted successfully!", "success")
      await this.loadUserPosts()
    } catch (error) {
      console.error("Error deleting post:", error)
      BlogUtils.showMessage("Error deleting post: " + error.message, "error")
    }
  },
}
