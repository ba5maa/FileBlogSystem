// Blog detail page functionality
window.BlogDetailPage = {
  async render(slug) {
    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="loading-spinner">
        <i class="fas fa-spinner fa-spin"></i>
        <p>Loading blog post...</p>
      </div>
    `

    try {
      const post = await window.BlogAPI.getPost(slug)
      await this.renderPost(post)
    } catch (error) {
      console.error("Error loading post:", error)
      appContainer.innerHTML = `
        <div class="blog-detail-page">
          <div class="blog-content" style="text-align: center; padding: 4rem 2rem;">
            <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: #dc3545; margin-bottom: 2rem;"></i>
            <h1>Post Not Found</h1>
            <p>The blog post you're looking for doesn't exist or has been removed.</p>
            <button class="btn btn-primary" onclick="window.BlogApp.navigate('${window.BlogConfig.ROUTES.HOME}')">
              <i class="fas fa-home"></i> Go Home
            </button>
          </div>
        </div>
      `
    }
  },

  async renderPost(post) {
    const appContainer = document.getElementById("app-container")
    const isAuthor = window.BlogAuth.isAuthenticated() && window.BlogAuth.user.username === post.authorUsername

    appContainer.innerHTML = `
      <div class="blog-detail-page">
        <div class="blog-hero">
          ${post.imageUrl ? `<img src="${window.BlogConfig.API_BASE_URL}${post.imageUrl}" alt="${post.title}" class="blog-hero-image">` : ""}
          <div class="blog-hero-content">
            <h1 class="blog-title">${post.title}</h1>
            <div class="blog-meta">
              <div class="blog-author">
                <i class="fas fa-user"></i>
                <span>@${post.authorUsername}</span>
              </div>
              <div class="blog-date">
                <i class="fas fa-calendar"></i>
                <span>${window.BlogUtils.formatDate(post.publishedDate || post.creationDate)}</span>
              </div>
              ${
                isAuthor
                  ? `
                <div class="blog-actions">
                  <button class="btn btn-outline" onclick="window.BlogApp.navigate('${window.BlogConfig.ROUTES.CREATE}', '${post.slug}')" style="background: rgba(255,255,255,0.2); border-color: rgba(255,255,255,0.5);">
                    <i class="fas fa-edit"></i> Edit
                  </button>
                </div>
              `
                  : ""
              }
            </div>
          </div>
        </div>
        
        <div class="blog-content">
          <div id="blog-content-rendered">
            ${window.BlogUtils.parseMarkdown(post.content)}
          </div>
          
          ${
            post.tags && post.tags.length > 0
              ? `
            <div class="blog-tags">
              ${post.tags
                .map((tagId) => {
                  const tag = this.getTagById(tagId)
                  return `<span class="blog-tag">#${tag ? tag.name : tagId}</span>`
                })
                .join("")}
            </div>
          `
              : ""
          }
          
          <div class="blog-engagement">
            <div class="engagement-stats">
              <button class="btn btn-outline like-btn" data-post-id="${post.id}">
                <i class="fas fa-heart"></i>
                <span>${post.likeCount || 0} Likes</span>
              </button>
            </div>
          </div>
        </div>
        
        <div id="comments-section">
          <!-- Comments will be loaded here -->
        </div>
      </div>
    `

    // Load comments
    await window.Comments.loadForPost(post.slug)
  },

  getTagById(tagId) {
    // This would need to be populated from the API
    return { name: tagId } // Fallback
  },
}
