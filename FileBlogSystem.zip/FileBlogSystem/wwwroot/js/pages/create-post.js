// Create/Edit post page functionality
window.CreatePostPage = {
  categories: [],
  tags: [],
  isEditing: false,
  editingSlug: null,
  BlogAPI: null,
  BlogUtils: null,
  BlogApp: null,
  BlogConfig: null,
  BlogAuth: null,

  async render(slug = null) {
    this.isEditing = !!slug
    this.editingSlug = slug

    await this.loadCategoriesAndTags()

    const appContainer = document.getElementById("app-container")

    appContainer.innerHTML = `
      <div class="create-blog-page">
        <div class="page-header">
          <h1>
            <i class="fas fa-${this.isEditing ? "edit" : "plus-circle"}"></i>
            ${this.isEditing ? "Edit Blog Post" : "Create New Blog Post"}
          </h1>
          <p>${this.isEditing ? "Update your blog post" : "Share your thoughts with the world"}</p>
        </div>

        <form id="blog-form" class="create-blog-form">
          <div class="form-section">
            <h3><i class="fas fa-heading"></i> Basic Information</h3>
            <div class="form-row">
              <div class="form-group">
                <label for="blog-title">
                  <i class="fas fa-font"></i>
                  Title
                </label>
                <input type="text" id="blog-title" placeholder="Enter your blog title..." required>
              </div>
              <div class="form-group">
                <label for="blog-category">
                  <i class="fas fa-folder"></i>
                  Category
                </label>
                <select id="blog-category" required>
                  <option value="">Select Category</option>
                  ${this.categories.map((cat) => `<option value="${cat.id}">${cat.name}</option>`).join("")}
                </select>
              </div>
            </div>
            
            <div class="form-group">
              <label for="blog-tags">
                <i class="fas fa-tags"></i>
                Tags
              </label>
              <select id="blog-tags" multiple>
                ${this.tags.map((tag) => `<option value="${tag.id}">${tag.name}</option>`).join("")}
              </select>
              <small>Hold Ctrl/Cmd to select multiple tags</small>
            </div>
          </div>

          <div class="form-section">
            <h3><i class="fas fa-edit"></i> Content</h3>
            <div class="form-group">
              <label for="blog-content">
                <i class="fas fa-file-alt"></i>
                Content (Markdown)
              </label>
              <div class="editor-toolbar">
                <button type="button" class="editor-btn" data-action="bold">
                  <i class="fas fa-bold"></i> Bold
                </button>
                <button type="button" class="editor-btn" data-action="italic">
                  <i class="fas fa-italic"></i> Italic
                </button>
                <button type="button" class="editor-btn" data-action="heading">
                  <i class="fas fa-heading"></i> Heading
                </button>
                <button type="button" class="editor-btn" data-action="link">
                  <i class="fas fa-link"></i> Link
                </button>
                <button type="button" class="editor-btn" data-action="image">
                  <i class="fas fa-image"></i> Image
                </button>
                <button type="button" class="editor-btn" data-action="quote">
                  <i class="fas fa-quote-left"></i> Quote
                </button>
              </div>
              <textarea id="blog-content" class="markdown-editor" placeholder="Write your blog content in Markdown..." required></textarea>
            </div>
          </div>

          <div class="form-section">
            <h3><i class="fas fa-image"></i> Featured Image</h3>
            <div class="form-group">
              <div class="image-upload-area" id="image-upload">
                <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: #ccc; margin-bottom: 1rem;"></i>
                <p>Click to upload or drag and drop an image</p>
                <input type="file" id="blog-image" accept="image/*" style="display: none;">
              </div>
              <div id="image-preview"></div>
            </div>
          </div>

          <div class="form-section">
            <h3><i class="fas fa-cog"></i> Publishing Options</h3>
            <div class="publish-options">
              <div class="form-row">
                <div class="form-group">
                  <label for="publish-status">
                    <i class="fas fa-eye"></i>
                    Status
                  </label>
                  <select id="publish-status">
                    <option value="draft">Save as Draft</option>
                    <option value="publish">Publish Now</option>
                    <option value="schedule">Schedule for Later</option>
                  </select>
                </div>
                <div class="form-group" id="schedule-group" style="display: none;">
                  <label for="schedule-datetime">
                    <i class="fas fa-calendar"></i>
                    Schedule Date & Time
                  </label>
                  <input type="datetime-local" id="schedule-datetime" min="${new Date().toISOString().slice(0, 16)}">
                </div>
              </div>
            </div>
          </div>

          <div class="publish-buttons">
            <button type="button" class="btn btn-outline" id="cancel-btn">
              <i class="fas fa-times"></i>
              Cancel
            </button>
            <button type="submit" class="btn btn-primary" id="submit-btn">
              <i class="fas fa-paper-plane"></i>
              <span id="submit-text">${this.isEditing ? "Update Post" : "Create Post"}</span>
            </button>
          </div>

          <div id="form-message" class="message" style="display: none;"></div>
        </form>
      </div>
    `

    if (this.isEditing) {
      await this.loadPostData(slug)
    }

    this.setupEventListeners()
  },

  async loadCategoriesAndTags() {
    try {
      ;[this.categories, this.tags] = await Promise.all([this.BlogAPI.getCategories(), this.BlogAPI.getTags()])
    } catch (error) {
      console.error("Error loading categories and tags:", error)
      this.categories = []
      this.tags = []
    }
  },

  async loadPostData(slug) {
    try {
      const post = await this.BlogAPI.getPost(slug)

      document.getElementById("blog-title").value = post.title || ""
      document.getElementById("blog-content").value = post.content || ""

      if (post.categories && post.categories.length > 0) {
        document.getElementById("blog-category").value = post.categories[0]
      }

      if (post.tags) {
        const tagSelect = document.getElementById("blog-tags")
        Array.from(tagSelect.options).forEach((option) => {
          option.selected = post.tags.includes(option.value)
        })
      }

      if (post.isDraft) {
        document.getElementById("publish-status").value = "draft"
      } else {
        document.getElementById("publish-status").value = "publish"
      }
    } catch (error) {
      console.error("Error loading post data:", error)
      this.BlogUtils.showMessage("Error loading post data", "error")
    }
  },

  setupEventListeners() {
    const form = document.getElementById("blog-form")
    const publishStatus = document.getElementById("publish-status")
    const scheduleGroup = document.getElementById("schedule-group")
    const imageUpload = document.getElementById("image-upload")
    const imageInput = document.getElementById("blog-image")
    const cancelBtn = document.getElementById("cancel-btn")

    // Form submission
    form.addEventListener("submit", this.handleSubmit.bind(this))

    // Cancel button
    cancelBtn.addEventListener("click", () => {
      this.BlogApp.navigate(this.BlogConfig.ROUTES.HOME)
    })

    // Publish status change
    publishStatus.addEventListener("change", (e) => {
      const submitText = document.getElementById("submit-text")
      if (e.target.value === "schedule") {
        scheduleGroup.style.display = "block"
        submitText.textContent = this.isEditing ? "Update & Schedule" : "Schedule Post"
      } else {
        scheduleGroup.style.display = "none"
        submitText.textContent =
          e.target.value === "draft"
            ? this.isEditing
              ? "Update Draft"
              : "Save Draft"
            : this.isEditing
              ? "Update Post"
              : "Publish Post"
      }
    })

    // Image upload
    imageUpload.addEventListener("click", () => imageInput.click())
    imageInput.addEventListener("change", this.handleImageUpload.bind(this))

    // Drag and drop for images
    imageUpload.addEventListener("dragover", (e) => {
      e.preventDefault()
      imageUpload.classList.add("dragover")
    })

    imageUpload.addEventListener("dragleave", () => {
      imageUpload.classList.remove("dragover")
    })

    imageUpload.addEventListener("drop", (e) => {
      e.preventDefault()
      imageUpload.classList.remove("dragover")
      const files = e.dataTransfer.files
      if (files.length > 0) {
        this.handleImageFile(files[0])
      }
    })

    // Editor toolbar
    document.querySelectorAll(".editor-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault()
        this.handleEditorAction(btn.dataset.action)
      })
    })
  },

  handleImageUpload(e) {
    const file = e.target.files[0]
    if (file) {
      this.handleImageFile(file)
    }
  },

  async handleImageFile(file) {
    if (!file.type.startsWith("image/")) {
      this.BlogUtils.showMessage("Please select an image file", "error")
      return
    }

    try {
      const base64 = await this.BlogUtils.readFileAsBase64(file)
      const preview = document.getElementById("image-preview")
      preview.innerHTML = `
        <img src="${base64}" alt="Preview" class="image-preview">
        <button type="button" class="btn btn-outline btn-sm" onclick="this.parentElement.innerHTML=''">
          <i class="fas fa-times"></i> Remove
        </button>
      `

      // Store the base64 data for submission
      document.getElementById("blog-image").dataset.base64 = base64
    } catch (error) {
      this.BlogUtils.showMessage("Error processing image", "error")
    }
  },

  handleEditorAction(action) {
    const textarea = document.getElementById("blog-content")
    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = textarea.value.substring(start, end)
    let replacement = ""

    switch (action) {
      case "bold":
        replacement = `**${selectedText || "bold text"}**`
        break
      case "italic":
        replacement = `*${selectedText || "italic text"}*`
        break
      case "heading":
        replacement = `## ${selectedText || "Heading"}`
        break
      case "link":
        replacement = `[${selectedText || "link text"}](url)`
        break
      case "image":
        replacement = `![${selectedText || "alt text"}](image-url)`
        break
      case "quote":
        replacement = `> ${selectedText || "quote text"}`
        break
    }

    textarea.value = textarea.value.substring(0, start) + replacement + textarea.value.substring(end)
    textarea.focus()
    textarea.setSelectionRange(start + replacement.length, start + replacement.length)
  },

  async handleSubmit(e) {
    e.preventDefault()

    const formData = new FormData(e.target)
    const messageElement = document.getElementById("form-message")
    const submitBtn = document.getElementById("submit-btn")

    // Disable submit button
    submitBtn.disabled = true
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...'

    try {
      const selectedTags = Array.from(document.getElementById("blog-tags").selectedOptions).map(
        (option) => option.value,
      )

      const publishStatus = document.getElementById("publish-status").value
      const scheduleDateTime = document.getElementById("schedule-datetime").value

      const postData = {
        title: document.getElementById("blog-title").value,
        content: document.getElementById("blog-content").value,
        categories: [document.getElementById("blog-category").value],
        tags: selectedTags,
        authorUsername: this.BlogAuth.user.username,
        isDraft: publishStatus === "draft" || publishStatus === "schedule",
        publishedDate: publishStatus === "publish" ? new Date().toISOString() : null,
        scheduledFor: publishStatus === "schedule" ? new Date(scheduleDateTime).toISOString() : null,
      }

      // Add image if uploaded
      const imageBase64 = document.getElementById("blog-image").dataset.base64
      if (imageBase64) {
        postData.base64Image = imageBase64
      }

      let result
      if (this.isEditing) {
        result = await this.BlogAPI.updatePost(this.editingSlug, postData)
      } else {
        result = await this.BlogAPI.createPost(postData)
      }

      this.BlogUtils.showMessage(
        `Post ${this.isEditing ? "updated" : "created"} successfully!`,
        "success",
        messageElement,
      )

      setTimeout(() => {
        this.BlogApp.navigate(this.BlogConfig.ROUTES.HOME)
      }, 1500)
    } catch (error) {
      console.error("Error saving post:", error)
      this.BlogUtils.showMessage(error.message, "error", messageElement)
    } finally {
      // Re-enable submit button
      submitBtn.disabled = false
      submitBtn.innerHTML = `<i class="fas fa-paper-plane"></i> <span id="submit-text">${this.isEditing ? "Update Post" : "Create Post"}</span>`
    }
  },
}

// Assuming these variables are declared elsewhere in your codebase
window.CreatePostPage.BlogAPI = window.BlogAPI
window.CreatePostPage.BlogUtils = window.BlogUtils
window.CreatePostPage.BlogApp = window.BlogApp
window.CreatePostPage.BlogConfig = window.BlogConfig
window.CreatePostPage.BlogAuth = window.BlogAuth
